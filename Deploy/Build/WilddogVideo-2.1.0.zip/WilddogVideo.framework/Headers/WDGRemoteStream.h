//
//  WDGRemoteStream.h
//  WilddogVideo
//
//  Created by Zheng Li on 8/23/16.
//  Copyright © 2016 WildDog. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

/**
 `WDGRemoteStream` 继承自 `WDGStream` ，具有 `WDGStream` 所有的方法。
 */
@interface WDGRemoteStream : WDGStream

@end

NS_ASSUME_NONNULL_END
